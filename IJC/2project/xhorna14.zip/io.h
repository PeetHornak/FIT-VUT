/*
 * Subor: htab_bucket_count.c
 * Projekt: IJC DU2, priklad b)
 * Datum: 24.4.2018
 * Autor: Peter Hornak - xhorna14
 * Poznamky: Hlavickovy subor pre io.c
 */


#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>

int get_word(char* s, int max, FILE* f);
